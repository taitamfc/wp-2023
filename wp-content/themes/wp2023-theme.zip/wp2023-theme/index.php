<?php
echo __FILE__;
while ( have_posts() ) {
    the_post();
    echo '<br>'.get_the_title();
}
