<?php
global $tpl_prefix,$theme_uri;
$tpl_prefix     = 'wp2023_theme';
$theme_uri      = get_template_directory_uri().'/assets';
$theme_version  = '1.0';

// Đăng ký các thành phần hỗ trợ cho theme
add_action( 'after_setup_theme', $tpl_prefix.'_theme_support' );
//Đăng ký style
add_action( 'wp_enqueue_scripts', $tpl_prefix.'_register_styles' );
//Đăng ký javascript
add_action( 'wp_enqueue_scripts', $tpl_prefix.'_register_scripts' );

function wp2023_theme_theme_support(){

}
function wp2023_theme_register_styles(){
    global $tpl_prefix,$theme_uri,$theme_version;
    // Đăng ký file style.css
    wp_enqueue_style( $tpl_prefix.'-style', get_stylesheet_uri(), array(), $theme_version );

    // Đăng ký các file css của theme
	wp_enqueue_style( $tpl_prefix.'-google-fonts-style', 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap', null, $theme_version);
	wp_enqueue_style( $tpl_prefix.'-font-awesome-style', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css', null, $theme_version);
	wp_enqueue_style( $tpl_prefix.'-animate-style', $theme_uri . '/lib/animate/animate.min.css', null, $theme_version);
	wp_enqueue_style( $tpl_prefix.'-owl-style', $theme_uri . '/lib/owlcarousel/assets/owl.carousel.min.css', null, $theme_version);
	wp_enqueue_style( $tpl_prefix.'-style-style', $theme_uri . '/css/style.css', null, $theme_version);
}
function wp2023_theme_register_scripts(){
    global $tpl_prefix,$theme_uri,$theme_version;
	wp_enqueue_script( $tpl_prefix.'bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js', array(), $theme_version, true );
	wp_enqueue_script( $tpl_prefix.'easing-js', $theme_uri .'/lib/easing/easing.min.js', array('jquery'), $theme_version, true );
	wp_enqueue_script( $tpl_prefix.'owl-js', $theme_uri .'/lib/owlcarousel/owl.carousel.min.js', array('jquery'), $theme_version, true );
	wp_enqueue_script( $tpl_prefix.'main-js', $theme_uri .'/js/main.js', array('jquery'), $theme_version, true );

}